﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using projet_formation.Tools;



namespace projet_formation
{
    public partial class donnees : MainPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!Page.IsPostBack)
            //{
            //    FORMATIONEntities f = new FORMATIONEntities();
            //    CrystalReport1 cr = new CrystalReport1();
            //    cr.SetDataSource(f.fonctionnaire.Select(c => new
            //    {
            //        SOM = c.SOM,
            //        nom_f = c.nom_f,
            //        prenom_f = c.prenom_f,
            //        poste = c.poste
            //    }).ToList());
            //    this.CrystalReportViewer1.ReportSource = cr;

            
            
            //}

        }

        protected void CrystalReportViewer1_Init(object sender, EventArgs e)
        {

        }
    }
}